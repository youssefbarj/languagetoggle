"use client"

import { useState } from "react"
import { Globe } from "lucide-react"

export function CourseSwitcher() {
  const [language, setLanguage] = useState<"en" | "fr">("en")
  const [isLoading, setIsLoading] = useState(true)
  const [isDropdownOpen, setIsDropdownOpen] = useState(false)
  const [closeTimeout, setCloseTimeout] = useState<NodeJS.Timeout | null>(null)

  const courseUrl = language === "en" ? "https://coassemble.com/learn/PCM72R" : "https://coassemble.com/learn/B54E5A"

  const handleMouseLeave = () => {
    const timeout = setTimeout(() => {
      setIsDropdownOpen(false)
    }, 200)
    setCloseTimeout(timeout)
  }

  const handleMouseEnter = () => {
    if (closeTimeout) clearTimeout(closeTimeout)
    setIsDropdownOpen(true)
  }

  return (
    <div className="relative w-full h-full bg-background">
      {isLoading && <div className="absolute inset-0 bg-muted animate-pulse z-40" />}

      <iframe
        key={language}
        src={courseUrl}
        className="w-full h-full border-0"
        title={`Course - ${language === "en" ? "English" : "Français"}`}
        allowFullScreen
        onLoad={() => setIsLoading(false)}
        onLoadStart={() => setIsLoading(true)}
      />

      <div className="fixed top-6 right-6 z-50" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
        <button className="p-2 rounded text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
          <Globe size={28} />
        </button>

        {isDropdownOpen && (
          <div className="absolute top-full right-0 mt-0 rounded-lg shadow-lg bg-card border border-border overflow-hidden">
            <button
              onClick={() => {
                setLanguage("en")
                setIsDropdownOpen(false)
              }}
              className={`block w-full text-left px-4 py-2 text-sm transition-colors ${
                language === "en" ? "bg-primary text-primary-foreground" : "hover:bg-muted text-foreground"
              }`}
            >
              English
            </button>
            <button
              onClick={() => {
                setLanguage("fr")
                setIsDropdownOpen(false)
              }}
              className={`block w-full text-left px-4 py-2 text-sm transition-colors ${
                language === "fr" ? "bg-primary text-primary-foreground" : "hover:bg-muted text-foreground"
              }`}
            >
              Français
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
